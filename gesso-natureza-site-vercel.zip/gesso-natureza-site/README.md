# Gesso Natureza — site pronto para Vercel

Site estático, responsivo e otimizado para SEO local, com:
- identidade verde e branca + logo enviada;
- WhatsApp pulsando para **11 99848-3800**;
- formulário de orçamento que monta a mensagem no WhatsApp;
- mapa da loja em Arujá;
- Instagram, telefone e e-mail;
- catálogo de materiais e serviços;
- faixa de marcas em looping;
- slider "antes e depois" com efeito de cortina;
- estrutura para Google Reviews via Google Places API;
- JSON-LD de LocalBusiness para SEO local;
- funcionamento sem banco de dados.

## Publicar no Vercel

1. Extraia o ZIP.
2. Crie um projeto no Vercel e importe a pasta.
3. Não precisa de build command: é um site estático + uma Serverless Function.
4. No Vercel, abra **Settings → Environment Variables** e adicione:
   - `GOOGLE_PLACES_API_KEY` = sua chave da Google Maps Platform com Places API habilitada.
5. Troque `https://SEU-DOMINIO-AQUI.com.br/` no `index.html` pelo domínio real.
6. No Vercel, aponte o domínio comprado para o projeto.

## Google Reviews

A área de avaliações funciona com uma busca do Google Places pelo nome + endereço. Sem a variável `GOOGLE_PLACES_API_KEY`, o site mostra avaliações de destaque estáticas como fallback. Com a chave configurada, nota, número de avaliações e até 6 reviews passam a ser carregados do Google.

Recomenda-se restringir a chave no Google Cloud para o uso da API necessária.

## Antes e depois

Quando você mandar as fotos:
- substitua `assets/antes.svg` por sua foto "antes";
- substitua `assets/depois.svg` por sua foto "depois";
- mantenha os mesmos nomes (ou ajuste os `src` no `index.html`).

O controle de cortina já está pronto.

## Imagens de materiais

Alguns cards usam ilustrações CSS para evitar dependência de estoque específico. O card de ferramentas usa uma foto ilustrativa remota. Você pode trocar os fundos por fotos reais da loja/estoque para melhorar conversão e SEO de imagens.

## Observação sobre marcas

A faixa de marcas foi feita como wordmarks estilizados para garantir que o site funcione sem depender de arquivos externos. Se você tiver os arquivos oficiais das logos Lotus, DeWalt, Stanley, Compel, Knauf, Âncora e Walsywa, eles podem ser colocados em `assets/brands/` e a faixa pode ser trocada para imagens oficiais.

## SEO

O site já traz títulos, descrição, keywords, canonical, Open Graph e Schema.org `LocalBusiness`, com foco em termos como:
- gesso em Arujá;
- drywall em Arujá;
- chapa drywall Arujá;
- gesso liso Arujá;
- forro drywall Arujá;
- divisória drywall Arujá;
- molduras de gesso Arujá;
- placa cimentícia Arujá.

Depois de colocar o domínio real, cadastre o site no Google Search Console e envie o sitemap quando houver um domínio definitivo.
