// Vercel Serverless Function
// Configure GOOGLE_PLACES_API_KEY in Vercel Environment Variables.
// The function searches the business by name/address and returns its Google rating + reviews.
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 's-maxage=900, stale-while-revalidate=3600');
  if (!process.env.GOOGLE_PLACES_API_KEY) {
    return res.status(503).json({ error: 'GOOGLE_PLACES_API_KEY não configurada' });
  }

  try {
    const key = process.env.GOOGLE_PLACES_API_KEY;
    const searchResponse = await fetch('https://places.googleapis.com/v1/places:searchText', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': key,
        'X-Goog-FieldMask': 'places.id,places.displayName,places.formattedAddress,places.rating,places.userRatingCount,places.reviews,places.googleMapsUri'
      },
      body: JSON.stringify({
        textQuery: 'Gesso Natureza, Avenida Dr. Armando Colângelo, 660, Arujá, SP',
        languageCode: 'pt-BR',
        regionCode: 'BR',
        maxResultCount: 1
      })
    });

    if (!searchResponse.ok) {
      const details = await searchResponse.text();
      return res.status(502).json({ error: 'Google Places error', details });
    }

    const json = await searchResponse.json();
    const place = json.places?.[0];
    if (!place) return res.status(404).json({ error: 'Local não encontrado no Google Places' });

    return res.status(200).json({ place });
  } catch (error) {
    return res.status(500).json({ error: 'Erro ao consultar avaliações', details: String(error) });
  }
}
