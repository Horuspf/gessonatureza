const $ = (s, el=document) => el.querySelector(s);
const $$ = (s, el=document) => [...el.querySelectorAll(s)];

document.addEventListener('DOMContentLoaded', () => {
  $('#year').textContent = new Date().getFullYear();

  const menu = $('.menu-toggle');
  const nav = $('#main-nav');
  menu?.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menu.setAttribute('aria-expanded', String(open));
  });
  $$('#main-nav a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

  // Before/after curtain effect.
  const compare = $('#compare');
  const range = $('input[type="range"]', compare);
  const beforeWrap = $('.compare-before-wrap', compare);
  const line = $('.compare-line', compare);
  const updateCompare = () => {
    const v = Number(range.value);
    beforeWrap.style.width = `${v}%`;
    line.style.left = `${v}%`;
  };
  range.addEventListener('input', updateCompare);
  updateCompare();

  // Product shortcuts pre-fill the contact form.
  $$('[data-product]').forEach(link => {
    link.addEventListener('click', () => {
      const select = $('select[name="interesse"]');
      if (select) select.value = 'Orçamento de material';
      const details = $('textarea[name="detalhes"]');
      if (details) details.value = `Tenho interesse em: ${link.dataset.product}. `;
    });
  });

  // WhatsApp quote form.
  $('#quote-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const msg = [
      'Olá, Gesso Natureza! Quero solicitar um orçamento.',
      `Nome: ${data.get('nome')}`,
      `WhatsApp: ${data.get('whatsapp')}`,
      `Interesse: ${data.get('interesse')}`,
      `Detalhes: ${data.get('detalhes') || 'Não informado'}`
    ].join('\n');
    window.open(`https://wa.me/5511998483800?text=${encodeURIComponent(msg)}`, '_blank', 'noopener');
  });

  loadGoogleReviews();
});

async function loadGoogleReviews() {
  try {
    const res = await fetch('/api/reviews');
    if (!res.ok) return;
    const data = await res.json();
    if (!data?.place) return;

    const rating = Number(data.place.rating);
    const count = Number(data.place.userRatingCount || 0);
    if (Number.isFinite(rating)) $('#rating-value').textContent = rating.toFixed(1).replace('.', ',');
    if (count) $('#rating-count').textContent = `${count.toLocaleString('pt-BR')} avaliações`;

    const reviews = Array.isArray(data.place.reviews) ? data.place.reviews : [];
    if (!reviews.length) return;
    $('#reviews-grid').innerHTML = reviews.slice(0,6).map(r => {
      const author = escapeHtml(r.authorAttribution?.displayName || 'Cliente');
      const text = escapeHtml(r.text?.text || '');
      const stars = '★'.repeat(Math.max(1, Math.min(5, Math.round(Number(r.rating)||5))));
      return `<article class="review">
        <div class="review-top"><b>${author}</b><span>${stars}</span></div>
        <p>“${text}”</p>
        <small>Google Reviews</small>
      </article>`;
    }).join('');
  } catch (_) {
    // Static fallback remains visible if the Google API isn't configured.
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  }[c]));
}
